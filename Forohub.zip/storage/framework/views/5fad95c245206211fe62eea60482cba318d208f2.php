

<?php $__env->startSection('description', 'Índice de comunidades. Aquí encontrarás un listado con todas las comunidades existentes en Forohub'); ?>

<?php if(isset($character)): ?>
	<?php $__env->startSection('title', 'Guía de comunidades ('.strtoupper($character).') - Forohub'); ?>
<?php else: ?>
	<?php $__env->startSection('title', 'Guía de comunidades - Forohub'); ?>
<?php endif; ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" type="text/css" href="/css/8AE3kMi5LgMMKoboN0dEZF8aHTmAeZ1xmReLDBB2cJd4ytvHNPlzfT0m3SI5lH40.css">
    <link rel="stylesheet" type="text/css" href="/css/PQgOkr0Wv7MpF16BvdG5aGgWNBlx5YF9y3ljjpHwKNESq23IJCczPi1rkXZDfcz1.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
	<script type="text/javascript" src="/js/guides.js"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('body'); ?>
	<?php echo $__env->make('layouts.desktop.templates.guides.guide_selection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('layouts.desktop.templates.guides.communities_guide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.desktop.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Forohub\resources\views/layouts/desktop/templates/guides/communities.blade.php ENDPATH**/ ?>