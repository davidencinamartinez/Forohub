<div class="lateral-cube lateral-community-data">
    <div class="lateral-title">Comunidad</div>
    <img class="lateral-community-logo" src="<?php echo e($community->logo); ?>">
    <a class="lateral-community-title" href="/c/<?php echo e($community->tag); ?>"><?php echo e($community->title); ?></a>
    <label class="lateral-community-tag">c/<?php echo e($community->tag); ?></label>
    <p class="lateral-community-description"><?php echo e($community->description); ?></p>
    <div style="display: inline-flex;">
        <div class="lateral-community-info" title="Miembros">
            <img class="lateral-community-users" src="/src/media/8tfjpJS2EukA0iPg27ikzxJizSu0UPOxYuLdQ9ipOqxgY2ccTNOVde5jjAroX1lh.png">
            <b><?php echo e($community->sub_count); ?></b>
        </div>
        <div class="lateral-community-info" title="Temas">
            <img class="lateral-community-users" src="/src/media/DVZoxBZv3qFwJqcTkAa2jrvJ49TcIPsMIzA2dJn0ytRWRwJt6daINZLImpsOAsAP.png">
            <b><?php echo e($community->threads_count); ?></b>
        </div>
        <div class="lateral-community-info" title="Posición en el Ranking">
            <img class="lateral-community-users" src="/src/media/xovLYVakqdxxo2OJVDPqbozbPp1W8InJqr4MbEPBHVzUmgM7Sf4uqFJMfGAUTalU.png">
            <b><?php echo e($community->index); ?></b>
        </div>
    </div>
</div>
<?php if(isset($thread)): ?>
    <?php if($thread->user_is_admin): ?>
        <div class="lateral-cube">
            <div class="lateral-title">Acciones</div>
            <div class="lateral-thread-options">
                <?php if($thread->closed == 0): ?>
                <button class="thread-options thread-close">Cerrar Tema 🔒</button>
                <?php endif; ?>
            </div>
        </div> 
    <?php endif; ?>
    <?php if($thread->user_is_leader): ?>
    <div class="lateral-cube">
            <div class="lateral-title">Acciones</div>
            <div class="lateral-thread-options">
                <?php if($thread->closed == 0): ?>
                <button class="thread-options thread-close">Cerrar Tema 🔒</button>
                <?php endif; ?>
                <button class="thread-options thread-delete">Eliminar Tema ⛔</button>
            </div>
        </div> 
    <?php endif; ?>
<?php endif; ?>
<?php if($community->community_rules->isNotEmpty()): ?>
    <div class="lateral-cube lateral-community-data">
        <div class="lateral-title">Reglamento</div>
        <?php $__currentLoopData = $community->community_rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="lateral-community-rule"><?php echo e($rule->rule); ?><label>▼</label>
                <div class="rule-description"><?php echo e($rule->rule_description); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<div class="lateral-cube lateral-community-data">
    <div class="lateral-title">Moderadores</div>
    <?php $__currentLoopData = $community->community_moderators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moderator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="lateral-community-moderators">
            <a href="/u/<?php echo e(strtolower($moderator->user->name)); ?>"><?php echo e($moderator->user->name); ?></a>
            <?php if($moderator->subscription_type == 5000): ?>
                <label>👑</label>
            <?php elseif($moderator->subscription_type == 2000): ?>
                <label>⭐</label>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="lateral-cube">
    <div class="lateral-title">Tags</div>
    <div class="lateral-community-tags">
        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <b class="lateral-community-keyword"><?php echo e($tag->tagname); ?></b>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php echo $__env->make('layouts.desktop.templates.lateral.lateral_help_center', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Forohub\resources\views/layouts/desktop/templates/lateral/lateral_community.blade.php ENDPATH**/ ?>