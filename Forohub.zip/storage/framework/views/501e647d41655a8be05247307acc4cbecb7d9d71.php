

<?php $__env->startSection('title', 'Restablecer contraseña - Forohub'); ?>

<?php $__env->startPush('styles'); ?>
	<link rel="stylesheet" type="text/css" href='<?php echo e(asset("/css/desktop/forgot_password.css")); ?>'>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('body'); ?>
	<div id="reset-password-container">
		<img src="/src/media/logo_black.webp">
		<div>
			<h2>Nueva contraseña:</h2>
			<input type="password" name="reset-password-new-password" autocomplete="off" value="" maxlength="64">
			<h2>Confirmar contraseña:</h2>
			<input type="password" name="reset-password-confirm-password" autocomplete="off" value="" maxlength="64">
		</div>
		<button id="reset-password-button">Restablecer Contraseña</button>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.desktop.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Forohub\resources\views/layouts/desktop/templates/user/reset_password.blade.php ENDPATH**/ ?>