

<?php $__env->startSection('title', 'Tops - Forohub'); ?>

<?php $__env->startSection('description', 'Lo mejor de lo mejor. Aquí encontrarás las mejores comunidades, los mejores temas y los usuarios más populares de la semana'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" type="text/css" href="/css/8AE3kMi5LgMMKoboN0dEZF8aHTmAeZ1xmReLDBB2cJd4ytvHNPlzfT0m3SI5lH40.css">
    <link rel="stylesheet" type="text/css" href="/css/Qaa3sfPYzde0Y65kX1TjRAqH2UvKzsvwoBavOYn43jhy4nbUHon8hW3I23crFrEc.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
	<script type="text/javascript" src="/js/guides.js"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('body'); ?>
<script type="text/javascript">
	console.log(<?php echo $threads; ?>);
</script>
<div style="width: 100%; text-align: center;">
	<div class="top-element-container">
		<div class="top-element-container-title">
			<b>Top Comunidades</b>
		</div>
		<?php $__currentLoopData = $communities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $community): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="top-element">
			<div style="display: grid; width: 100%;">
				<div style="display: flex; align-items: center; width: 100%; margin: 10px 0px;">
					<div style="width: 30%;">
						<img class="top-element-image" src="<?php echo e($community->logo); ?>">
					</div>
					<div class="top-element-data">
						<b><?php echo e($community->title); ?></b>
						<i>c/<?php echo e($community->tag); ?></i>
					</div>
					<div class="top-position">
					<?php if($loop->index == 0): ?>
					<b class="top-position-first" style=>🥇</b>
					<?php elseif($loop->index == 1): ?>
					<b class="top-position-second">🥈</b>
					<?php elseif($loop->index == 2): ?>
					<b class="top-position-third">🥉</b>
					<?php endif; ?>
					</div>
				</div>
				<div>
					<b style="margin-left: 20px;">Estadísticas de los últimos 7 días:</b>
				</div>
				<div class="top-element-stats">
					<div style="width: 25%; text-align: center;" title="Usuarios">
						<img src="/src/media/8tfjpJS2EukA0iPg27ikzxJizSu0UPOxYuLdQ9ipOqxgY2ccTNOVde5jjAroX1lh.png" style="width: 32px; height: 32px; vertical-align: bottom;">
						<label style="margin-left: 2px;">+<?php echo e($community->users_count); ?></label>
					</div>
					<div style="width: 25%; text-align: center;" title="Temas">
						<img src="/src/media/DVZoxBZv3qFwJqcTkAa2jrvJ49TcIPsMIzA2dJn0ytRWRwJt6daINZLImpsOAsAP.png" style="width: 32px; height: 32px; vertical-align: bottom;">
						<label style="margin-left: 2px;">+<?php echo e($community->threads_count); ?></label>
					</div>
					<div style="width: 25%; text-align: center;" title="Votos Positivos">
						<img src="/src/media/nAiEBnmyVoFYNBhtaIw8mIXoMmNaxQLOiayJ9FM0PhVQiGJ6adiTUFj4IqidT560.png" style="width: 32px; height: 32px; vertical-align: bottom;">
						<label style="margin-left: 2px;">+<?php echo e($community->upvotes_count); ?></label>
					</div>
					<div style="width: 25%; text-align: center;" title="Mensajes">
						<img src="/src/media/bGAP31dQIA6Y3fxrmZ9IMV4Mc4h2nokrgeZB2lqPvmJcKXXCENPWUpwMzDu4ZfB7.png" style="width: 32px; height: 32px; vertical-align: bottom;">
						<label style="margin-left: 2px;">+<?php echo e($community->replies_count); ?></label>
					</div>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<div class="top-element-container" style="min-width: 350px; max-width: 400px; width: 33.3%">
		<div class="top-element-container-title">
			<b>Top Usuarios</b>
		</div>
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="top-element">
			<div style="display: grid; width: 100%;">
				<div style="display: flex; align-items: center; width: 100%; margin: 10px 0px;">
					<div style="width: 30%;">
						<img class="top-element-image" src="<?php echo e($user->avatar); ?>">
					</div>
					<div class="top-element-data">
						<b style="font-size: 20px; text-overflow: ellipsis; overflow: hidden; white-space: nowrap;"><?php echo e($user->name); ?></b>
						<i style="text-overflow: ellipsis; overflow: hidden; white-space: nowrap;"><?php echo e($user->about); ?></i>
					</div>
					<div style="width: 30%; font-size: 30px; text-align: center;">
					<?php if($loop->index == 0): ?>
					<b style="border-radius: 50%; padding: 10px; background-image: linear-gradient(to top, #BF953F 10%, #ffef50 45%, #BF953F); border: solid 2px black;">🥇</b>
					<?php elseif($loop->index == 1): ?>
					<b style="border-radius: 50%; padding: 10px; background-image: linear-gradient(to top, #848484 10%, #cccccc 45%, #848484); border: solid 2px black;">🥈</b>
					<?php elseif($loop->index == 2): ?>
					<b style="border-radius: 50%; padding: 10px; background-image: linear-gradient(to top, #946700 10%, #da9800 45%, #946700); border: solid 2px black;">🥉</b>
					<?php endif; ?>
					</div>
				</div>
				<div>
					<b style="margin-left: 20px;">Estadísticas de los últimos 7 días:</b>
				</div>
				<div style="display: flex; margin: 10px 0px; font-weight: bold; width: 85%; margin: 20px auto;">
					<div style="width: 25%; text-align: center;" title="Karma">
						<img src="/src/media/wVgT7mQbXswj1sh0fK9zmMdMAz0JM8zQh2kgd8lS5tFi7WEqgg2HSDAI9IO7EUAv.png" style="width: 32px; height: 32px; vertical-align: bottom;">
						<label style="margin-left: 2px;"><?php echo e($user->score); ?></label>
					</div>
					<div style="width: 25%; text-align: center;" title="Temas">
						<img src="src/media/DVZoxBZv3qFwJqcTkAa2jrvJ49TcIPsMIzA2dJn0ytRWRwJt6daINZLImpsOAsAP.png" style="width: 32px; height: 32px; vertical-align: bottom;">
						<label style="margin-left: 2px;">+<?php echo e($user->threads_count); ?></label>
					</div>
					<div style="width: 25%; text-align: center;" title="Votos Positivos">
						<img src="/src/media/nAiEBnmyVoFYNBhtaIw8mIXoMmNaxQLOiayJ9FM0PhVQiGJ6adiTUFj4IqidT560.png" style="width: 32px; height: 32px; vertical-align: bottom;">
						<label style="margin-left: 2px;">+<?php echo e($user->upvotes_count); ?></label>
					</div>
					<div style="width: 25%; text-align: center;" title="Mensajes">
						<img src="/src/media/bGAP31dQIA6Y3fxrmZ9IMV4Mc4h2nokrgeZB2lqPvmJcKXXCENPWUpwMzDu4ZfB7.png" style="width: 32px; height: 32px; vertical-align: bottom;">
						<label style="margin-left: 2px;">+<?php echo e($user->replies_count); ?></label>
					</div>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<div class="top-element-container" style="min-width: 350px; max-width: 400px; width: 33.3%">
		<div class="top-element-container-title">
			<b>Top Temas</b>
		</div>
		<?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="top-element">
			<div style="display: grid; width: 100%;">
				<div style="display: flex; align-items: center; width: 100%; margin: 10px 0px;">
					<div style="width: 30%;">
						<?php if($thread->type == "THREAD_POST"): ?>
						<img class="top-element-image" src="https://res.cloudinary.com/dt4uoou5x/image/upload/v1613559834/wtp0aa.webp" title="Post" style="border-radius: unset; border: unset; background-color: unset;"> 
						<?php elseif($thread->type == "THREAD_MEDIA"): ?>
						<img class="top-element-image" src="https://res.cloudinary.com/dt4uoou5x/image/upload/v1613559834/ogyfr6.webp" title="Multimedia" style="border-radius: unset; border: unset; background-color: unset;"> 
						<?php elseif($thread->type == "THREAD_YT"): ?>
						<img class="top-element-image" src="https://res.cloudinary.com/dt4uoou5x/image/upload/v1613559834/jbsvgx.webp" title="Youtube" style="border-radius: unset; border: unset; background-color: unset;"> 
						<?php elseif($thread->type == "THREAD_POLL"): ?>
						<img class="top-element-image" src="https://res.cloudinary.com/dt4uoou5x/image/upload/v1613559834/cylm0g.webp" title="Encuesta" style="border-radius: unset; border: unset; background-color: unset;"> 
						<?php endif; ?>
					</div>
					<div class="top-element-data">
						<b style="font-size: 20px; text-overflow: ellipsis; overflow: hidden; white-space: nowrap;"><?php echo e($thread->title); ?></b>
						<i style="text-overflow: ellipsis; overflow: hidden; white-space: nowrap;">c/<?php echo e($thread->id); ?></i>
					</div>
					<div style="width: 30%; font-size: 30px; text-align: center;">
					<?php if($loop->index == 0): ?>
					<b style="border-radius: 50%; padding: 10px; background-image: linear-gradient(to top, #BF953F 10%, #ffef50 45%, #BF953F); border: solid 2px black;">🥇</b>
					<?php elseif($loop->index == 1): ?>
					<b style="border-radius: 50%; padding: 10px; background-image: linear-gradient(to top, #848484 10%, #cccccc 45%, #848484); border: solid 2px black;">🥈</b>
					<?php elseif($loop->index == 2): ?>
					<b style="border-radius: 50%; padding: 10px; background-image: linear-gradient(to top, #946700 10%, #da9800 45%, #946700); border: solid 2px black;">🥉</b>
					<?php endif; ?>
					</div>
				</div>
				<div>
					<b style="margin-left: 20px;">Estadísticas de los últimos 7 días:</b>
				</div>
				<div style="display: flex; margin: 10px 0px; font-weight: bold; width: 85%; margin: 20px auto;">
					<div style="width: 25%; text-align: center;" title="Votos Positivos">
						<img src="/src/media/nAiEBnmyVoFYNBhtaIw8mIXoMmNaxQLOiayJ9FM0PhVQiGJ6adiTUFj4IqidT560.png" style="width: 32px; height: 32px; vertical-align: bottom;">
						<label style="margin-left: 2px;">+<?php echo e($thread->upvotes_count); ?></label>
					</div>
					<div style="width: 25%; text-align: center;" title="Mensajes">
						<img src="/src/media/bGAP31dQIA6Y3fxrmZ9IMV4Mc4h2nokrgeZB2lqPvmJcKXXCENPWUpwMzDu4ZfB7.png" style="width: 32px; height: 32px; vertical-align: bottom;">
						<label style="margin-left: 2px;">+<?php echo e($thread->replies_count); ?></label>
					</div>
					<?php if($thread->nsfw == 1): ?>
					<div style="width: 20%; text-align: center; display: flex; font-size: 20px; justify-content: flex-end; align-self: center;">📑</div>
					<?php else: ?>
					<div style="width: 20%; text-align: center; display: flex; font-size: 20px; justify-content: flex-end; filter: grayscale(1); align-self: center;">📑</div>
					<?php endif; ?>
					<?php if($thread->nsfw == 1): ?>
					<div style="width: 20%; text-align: center; display: flex; font-size: 20px; justify-content: center; align-self: center;">🔞</div> 
					<?php else: ?>
					<div style="width: 20%; text-align: center; display: flex; font-size: 20px; justify-content: center; filter: grayscale(1); align-self: center;">🔞</div>
					<?php endif; ?>
					<?php if($thread->nsfw == 1): ?>
					<div style="width: 20%; text-align: center; display: flex; font-size: 20px; justify-content: left; align-self: center;">💥</div>
					<?php else: ?>
					<div style="width: 20%; text-align: center; display: flex; font-size: 20px; justify-content: left; filter: grayscale(1); align-self: center;">💥</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.desktop.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Forohub\resources\views/layouts/desktop/templates/tops/tops.blade.php ENDPATH**/ ?>