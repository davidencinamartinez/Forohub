

<?php $__env->startSection('title', $thread->title.' - Forohub'); ?>

<?php $__env->startSection('description', $meta_description); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/LorEh6J3JDeDflokqvfpsYgK7yDIvyMl6qcULvqIgR8qGZ3zkagvsvtpw5pZ1rr8.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/dYLviCaMKKoganQbQUa7lwhnlGund6PVLESCtn4jSJ00xXWCahDLUxHsMjyDFpHu.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/L02AaerYckTaqAgneODgPhYXNglw7NjScj7Wvu2SulxxotSZiCMHJpQ7fQKdIfU0.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/lMCdpjFSu5vMoCSIeycbdokrQqWyPZNLmvjARCwXWC4bkKQCg4BWhlpTQ1gqxMPI.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<?php if($thread->user_is_admin || $thread->user_is_leader): ?>
    <script type="text/javascript" src="/js/thread_actions.js"></script>
<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('body'); ?>
<?php if($thread->communities->background): ?>
    <script type="text/javascript">
        if (getCookie('DARK_THEME_CHECK') == 'TRUE') {
            $('html').css('backgroundImage', 'linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(<?php echo $thread->communities->background; ?>)');
        } else {
            $('html').css('backgroundImage', 'linear-gradient(rgba(255,255,255,0.5), rgba(255,255,255,0.5)), url(<?php echo $thread->communities->background; ?>');
        }
    </script>
    <style type="text/css">
        html {
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
            background-attachment: fixed;
        }
    </style>
<?php endif; ?>
<div class="index-panel">
    <div style="width: 10%;"></div>
    <div class="threads-panel">
        <?php echo $__env->make('layouts.desktop.templates.thread.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="thread-replies">
            <?php $__currentLoopData = $thread_replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('layouts.desktop.templates.thread.replies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="lateral-panel">
        <?php echo $__env->make('layouts.desktop.templates.lateral.lateral_community', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php if($thread_replies->hasPages()): ?>
    <div style="text-align: center;">
        <div class="pageSelector">
            <?php echo $thread_replies->links(); ?>

        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.desktop.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Forohub\resources\views/layouts/desktop/templates/thread.blade.php ENDPATH**/ ?>