<?php if($thread_reports->isEmpty()): ?>
    <h2>No se han encontrado reportes de temas</h2>
<?php else: ?>
    <h2>Reportes de temas</h2>
    <div class="thread-reports-container">
    <?php $__currentLoopData = $thread_reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread_report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($thread_report->solved == 0): ?>
        <div class="thread-report unsolved" data-id="<?php echo e($thread_report->id); ?>">
        <?php else: ?>
        <div class="thread-report solved" data-id="<?php echo e($thread_report->id); ?>">
        <?php endif; ?>
            <div class="report-type">
                <label title="Tema">📝</label>
            </div>
            <div class="report-data">
                <label class="report-cause"><?php echo e($thread_report->report_type); ?></label>
                <label><b>Fecha: </b><label class="report-date"><?php echo e($thread_report->created_at); ?></label></label>
                <label><b>Enviado por: </b><a href="/u/<?php echo e(strtolower($thread_report->author->name)); ?>"><?php echo e($thread_report->author->name); ?></a></label>
                <?php if($thread_report->solved == 0): ?>
                <label><b>Estado: </b>Pendiente de revisión ❗</label>
                <?php else: ?>
                <label><b>Estado: </b>Resuelto ✔️</label>
                <?php endif; ?>
                <label><b>Fecha de vencimiento: </b><?php echo e(date('d/m/Y (H:i)', strtotime($thread_report->created_at->addDays(30)))); ?></label>
                <?php if($thread_report->description): ?>
                <label class="report-description"><b>Descripción: </b><?php echo e($thread_report->description); ?></label>
                <?php endif; ?>
            </div>
            <div class="report-actions">
                <a href="/c/<?php echo e($community->tag); ?>/t/<?php echo e($thread_report->thread_id); ?>"><button>Ver Tema ↩️</button></a>
                <?php if($thread_report->solved == 0): ?>
                <button class="thread-solve">Marcar como resuelto ✔️</button>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?><?php /**PATH C:\Users\david\Forohub\resources\views/layouts/desktop/templates/community/thread_reports.blade.php ENDPATH**/ ?>