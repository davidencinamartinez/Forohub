

<?php $__env->startSection('title', 'Forohub'); ?>

<?php $__env->startSection('description', $meta_description); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/B7o87L2YkZdnuQkqz68BKA35j2mc0OLjT86jSOrps19DHKjTHCVjMrjaQCpz7m6k.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/dYLviCaMKKoganQbQUa7lwhnlGund6PVLESCtn4jSJ00xXWCahDLUxHsMjyDFpHu.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/L02AaerYckTaqAgneODgPhYXNglw7NjScj7Wvu2SulxxotSZiCMHJpQ7fQKdIfU0.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/lMCdpjFSu5vMoCSIeycbdokrQqWyPZNLmvjARCwXWC4bkKQCg4BWhlpTQ1gqxMPI.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('body'); ?>
<?php if(session('status')): ?>
    <script type="text/javascript">
        $(document).ready(function() {
           userVerifiedSuccess();
        });
    </script>
<?php endif; ?>
<?php if(session('warning')): ?>
  <div class="alert alert-warning">
    <?php echo e(session('warning')); ?>

  </div>
<?php endif; ?>
<div class="index-panel">
    <div style="width: 10%"></div>
    <div class="threads-panel">
    <?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('layouts.desktop.templates.thread.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    <div class="lateral-panel">
        <div class="lateral-cube top-communities">
            <div class="lateral-title">TOP Comunidades</div>
            <?php $__currentLoopData = $top_communities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top_community): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="top-community" href="c/<?php echo e($top_community->tag); ?>">
                    <img class="top-community-logo" src="<?php echo e($top_community->logo); ?>">
                    <b>c/<?php echo e($top_community->tag); ?></b>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="lateral-cube user-actions">
            <div class="lateral-title">Acciones</div>
            <a class="required-auth" href="/crear/tema">Crear Tema</a>
            <a class="required-auth" href="/crear/comunidad">Crear Comunidad</a>
        </div>
        <div class="lateral-cube last-replies">
            <div class="lateral-title">Últimos mensajes</div>
                <?php $__currentLoopData = $latest_replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $last_reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="last-reply">
                        <a href="c/<?php echo e($last_reply->tag); ?>/t/<?php echo e($last_reply->id); ?>"><?php echo e($last_reply->title); ?></a>
                        <br>
                        <div>
                            <a href="/u/<?php echo e(strtolower($last_reply->name)); ?>"><?php echo e($last_reply->name); ?></a> · <label class="reply-date"><?php echo e($last_reply->created_at); ?></label>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="lateral-cube forum-stats">
            <div class="lateral-title">Estadísticas de Forohub</div>
            <ul style="list-style-type: circle;">
                <li><b>Comunidades:</b> <?php echo e($fh_data['count_communities']); ?></li>
                <li><b>Miembros:</b> <?php echo e($fh_data['count_users']); ?></li>
                <li><b>Temas:</b> <?php echo e($fh_data['count_threads']); ?></li>
                <li><b>Mensajes:</b> <?php echo e($fh_data['count_replies']); ?></li>
            </ul>
        </div>
        <?php echo $__env->make('layouts.desktop.templates.lateral.lateral_help_center', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php if($threads->hasPages()): ?>
  <div style="text-align: center;">
    <div class="pageSelector">
      <?php echo $threads->links(); ?>

    </div>
  </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.desktop.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Forohub\resources\views/layouts/desktop/templates/index.blade.php ENDPATH**/ ?>