

<?php $__env->startSection('title', $data->name.' - Forohub'); ?>

<?php $__env->startSection('description', $meta_description); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" type="text/css" href="/css/LorEh6J3JDeDflokqvfpsYgK7yDIvyMl6qcULvqIgR8qGZ3zkagvsvtpw5pZ1rr8.css">
    <link rel="stylesheet" type="text/css" href="/css/dYLviCaMKKoganQbQUa7lwhnlGund6PVLESCtn4jSJ00xXWCahDLUxHsMjyDFpHu.css">
    <link rel="stylesheet" type="text/css" href="/css/L02AaerYckTaqAgneODgPhYXNglw7NjScj7Wvu2SulxxotSZiCMHJpQ7fQKdIfU0.css">
    <link rel="stylesheet" type="text/css" href="/css/lMCdpjFSu5vMoCSIeycbdokrQqWyPZNLmvjARCwXWC4bkKQCg4BWhlpTQ1gqxMPI.css">
    <link rel="stylesheet" type="text/css" href="/css/RUF5xFYFWBPk4UkDWGl0ZfOqJaRw7DbTYQtu3DiqNSwAfv5mP4BXZXCg5xAflVs0.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
	<script type="text/javascript" src="/js/profile_actions.js"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('body'); ?>
	<div class="index-panel">
	    <div style="width: 10%"></div>
	    <div class="threads-panel">
	    	<?php if(Auth::check() && Auth::user()->id == $data->id): ?>
	    	<div class="profile-configuration">
				<div class="profile-configuration-title">Configuración</div>
	    	    <div class="profile-configuration-data">
	    	    	<div>
		        		<h4 class="input-title">Fecha de registro: <label class="user-register-date" style="text-transform: capitalize;"><?php echo e(Auth::user()->created_at); ?></label></h4>
		        	</div>
	    	    	<div class="profile-configuration-set configuration-password">
	    	    		<div>
			        		<b class="input-title">Contraseña: </b>
			        		<label style="margin-left: 10px;">**********</label>
			        		<img class="edit-element" src="/src/media/edit_icon.webp">
			        		<div class="configuration-password-panel configuration-panel">
			        			<h3>Cambiar contraseña</h3>
			        			<div class="old-password">
			        				<b>Contraseña actual:</b>
			        				<input type="password" class="form-input" placeholder="Contraseña actual" autocomplete="off" maxlength="64">
			        				<div class="character-counter">
			        					<label>0</label>
			        					<label>/64</label>
			        				</div>
			        			</div>
			        			<div class="new-password">
			        				<b>Nueva contraseña:</b>
			        				<input type="password" class="form-input" placeholder="Nueva contraseña" autocomplete="off" maxlength="64">
			        				<div class="character-counter">
			        					<label>0</label>
			        					<label>/64</label>
			        				</div>
			        			</div>
			        			<button class="configuration-update-password">Actualizar</button></div>
		        		</div>
		        	</div>
		        	<div class="profile-configuration-set configuration-title">
		        		<div>
			        		<b class="input-title">Título: </b>
			        		<label style="margin-left: 10px;"><?php echo e(Auth::user()->about); ?></label>
			        		<img class="edit-element" src="/src/media/edit_icon.webp">
			        		<div class="configuration-title-panel configuration-panel">
			        			<h3>Modificar título</h3>
			        			<div class="new-title">
			        				<b>Nuevo título:</b>
			        				<input type="search" class="form-input" placeholder="Título" autocomplete="off" maxlength="40">
			        				<div class="character-counter">
			        					<label>0</label>
			        					<label>/40</label>
			        				</div>
			        			</div>
			        			<button class="configuration-update-title">Actualizar</button>
			        		</div>
		        		</div>
		        	</div>
	    	    </div>
	    	</div>
	    	<?php endif; ?>
	    	<?php if($threads->isNotEmpty()): ?>
			    <?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			        <?php echo $__env->make('layouts.desktop.templates.thread.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
				<h3>Este usuario no ha creado ningún tema todavía</h3>
			<?php endif; ?>
		</div>
	    <div class="lateral-panel">
	    	<div class="lateral-cube">
	            <div class="lateral-title">Perfil</div>
	            <div class="profile-cube">
	            	<img src="<?php echo e($data->avatar); ?>">
	            	<div>
	            		<b><?php echo e($data->name); ?></b>
	            		<i><?php echo e($data->about); ?></i>
	            	</div>
	            </div>
	        </div>
	        <?php if(Auth::check() && Auth::user()->id == $data->id): ?>
	        <div class="lateral-cube user-actions">
	            <div class="lateral-title">Acciones</div>
	            <div class="profile-panel-buttons">
	            	<button class="profile-configuration-trigger">Configuración</button>
	            	<button>Suscripciones</button>
	            	<button class="profile-dark-theme">Tema Oscuro</button>
	        	</div>
	        </div>
	        <?php endif; ?>
	        <div class="lateral-cube">
	            <div class="lateral-title">Estadísticas</div>
            	<div class="profile-stats-cube">
            		<div title="Karma">
    		        	<img src="/src/media/wVgT7mQbXswj1sh0fK9zmMdMAz0JM8zQh2kgd8lS5tFi7WEqgg2HSDAI9IO7EUAv.png">
    		            <b><?php echo e($data->karma); ?></b>
    		        </div>
    		        <div title="Mensajes">
			            <img src="/src/media/bGAP31dQIA6Y3fxrmZ9IMV4Mc4h2nokrgeZB2lqPvmJcKXXCENPWUpwMzDu4ZfB7.png">
			            <b><?php echo e($data->messages_count); ?></b>
			        </div>
			        <div title="Temas">
			            <img src="/src/media/DVZoxBZv3qFwJqcTkAa2jrvJ49TcIPsMIzA2dJn0ytRWRwJt6daINZLImpsOAsAP.png">
			            <b><?php echo e($data->threads_count); ?></b>
			        </div>
			        <div title="Votos Positivos">
			            <img src="/src/media/nAiEBnmyVoFYNBhtaIw8mIXoMmNaxQLOiayJ9FM0PhVQiGJ6adiTUFj4IqidT560.png">
			            <b><?php echo e($data->upvotes); ?></b>
			        </div>
			        <div title="Votos Negativos">
			            <img src="/src/media/a7Vc4igYwqdHCM2UtoSinG5qTZCk9pD6mOT3sul7bl7OJq26ZN0qf7BPxD7KYklW.png">
			            <b><?php echo e($data->downvotes); ?></b>
			        </div>
			        <div title="Posición en el Ranking">
			            <img src="/src/media/cjnMbZ9bq1KbMhr4JnxQOCI6rPsGI2rQ2P83jM3jVKlZdC7tHEChyBGnY6U3tL8b.png">
			            <b><?php echo e($data->placing); ?></b>
			        </div>
            	</div>
	        </div>
	        <?php if($rewards->isNotEmpty()): ?>
	        <div class="lateral-cube">
	            <div class="lateral-title">Logros</div>
            	<div class="profile-rewards-text">
            		<b>Aquí podrás ver los últimos logros del usuario</b>
            		<label>Desliza el cursor sobre el logro para obtener más información</label>
            	</div>
	            <div class="profile-cube profile-rewards-cube">
	            	<?php $__currentLoopData = $rewards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_reward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            	<img src="/src/rewards/<?php echo e($user_reward->reward->filename); ?>" data-title="<?php echo e($user_reward->reward->name); ?>" data-description="<?php echo e($user_reward->reward->text); ?>">
	            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	            </div>
	        </div>
	        <?php endif; ?>
	        <?php echo $__env->make('layouts.desktop.templates.lateral.lateral_help_center', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	    </div>
	</div>
	<?php if($threads->hasPages()): ?>
	    <div style="text-align: center;">
	        <div class="pageSelector">
	            <?php echo $threads->links(); ?>

	        </div>
	    </div>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.desktop.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Forohub\resources\views/layouts/desktop/templates/user/profile.blade.php ENDPATH**/ ?>