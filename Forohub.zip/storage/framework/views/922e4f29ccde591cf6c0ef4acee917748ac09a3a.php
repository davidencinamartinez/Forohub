<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php if(isset($unread_notifications)): ?>
		<title>(<?php echo e($unread_notifications); ?>) <?php echo $__env->yieldContent('title'); ?></title>
	<?php else: ?>
		<title><?php echo $__env->yieldContent('title'); ?></title>
	<?php endif; ?>
		<link rel="shortcut icon" type="image/png" href="/src/media/favicon.png">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/327Yoc5QodjbmDMrPGvyS4bb5OWaxwuVzqQGR8DEpwybWUOAQj9c1ZMnOqwmykTm.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/3SNhbCgEn43DJcWvdwn1GRdusN2TSe5OnKujM0fAnOjwofJyLf1DZqRKbpf49Qxw.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/7gRTS9REZpLyk7xC8v8z0RFI58bZ0LhMhhEA0m3X8IgNrMDYcRPTO2a64ZN1hCoN.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/8AE3kMi5LgMMKoboN0dEZF8aHTmAeZ1xmReLDBB2cJd4ytvHNPlzfT0m3SI5lH40.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/Ac7PvcuJsoVpdzpSoOMzfwJeoCGY8lDJaPjgd7JtVCHPldfs3jy12sw7wcxRZYiF.css')); ?>">
	<?php echo $__env->yieldPushContent('styles'); ?>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script type="text/javascript" src="/js/moment_js/moment.js"></script>
		<script type="text/javascript" src="/js/moment_js/es.js"></script>
		<?php if(Auth::check()): ?>
		<script src="<?php echo e(asset('/js/authenticated.js')); ?>"></script>
		<?php else: ?>
		<script src="<?php echo e(asset('/js/non_authenticated.js')); ?>"></script>
		<?php endif; ?>
		<script src="<?php echo e(asset('/js/scriptsheet.js')); ?>"></script>
		<!--<script type="text/javascript" src="<?php echo e(asset('/js/zuv1CthgRAZYP0xk5OBvYDGVjcmt7dyPKmuMq7ixrgFLlPvVTFFldb4mDlohLfLv.js')); ?>"></script>-->
		<meta content="<?php echo e(csrf_token()); ?>" name="csrf-token" />
	<?php echo $__env->yieldPushContent('scripts'); ?>
</head>
<body>
	<div class="header">
		<a href="/">
			<img class="main-logo" src="/src/media/logo_white.webp" alt="forohub_logo" title="Forohub" clickeable>
		</a>
		<div class="user-login">
			<?php if(Auth::check()): ?>
				<div class="user-header-panel">
					<?php if(isset($unread_notifications)): ?>
						<?php if($unread_notifications > 9): ?>
							<div class="user-unread-notifications">9+</div>
						<?php else: ?>
							<div class="user-unread-notifications"><?php echo e($unread_notifications); ?></div>
						<?php endif; ?>
					<?php endif; ?>
					<div>
						<img class="user-avatar" src="<?php echo e(Auth::user()->avatar); ?>">
						<div class="user-info">
							<b title="<?php echo e(Auth::user()->name); ?>"><?php echo e(Auth::user()->name); ?></b>
							<label title="<?php echo e(Auth::user()->about); ?>"><?php echo e(Auth::user()->about); ?></label>
						</div>
					</div>
					<div class="user-buttons" style="text-align: center; display: inline-block;">
						<a class="user-profile" href="/u/<?php echo e(strtolower(Auth::user()->name)); ?>">
					  		<button>Mi Perfil</button>
					  	</a>
					  	<button id="user-rewards">Logros</button>
					  	<button id="user-notifications">Notificaciones</button>
						<form id="logout-form" action="<?php echo e(route('logout')); ?>" style="float: right;" method="POST">
							<?php echo e(csrf_field()); ?>

					 		<button type="submit" style="margin-left: 4px;">Salir</button>
						</form>
					</div>
				</div>
			<?php else: ?>
				<form action="<?php echo e(route('login')); ?>" method='POST'>
					<?php echo csrf_field(); ?>
					<input type="text" name="name" maxlength="20" title="Usuario" placeholder="Usuario">
					<input type="password" name="password" title="Contraseña" placeholder="Contraseña">
					<button type="submit" title="Entrar">Entrar</button>
				</form>
				<span class="register-label">
					<b>Has olvidado tu contraseña?
						<a style="color: #FFB600; cursor: pointer;" onclick="passwordResetModal()">Click aquí</a>
					</b>
				</span>
				<br>
				<span class="register-label">
					<b>No tienes cuenta?
						<a style="color: #FFB600; cursor: pointer;" onclick="registerModal()">Regístrate</a>
					</b>
				</span>
				<?php if(session()->has('err')): ?>
					<br>
					<p class="error" style="display: contents"><?php echo e(session('err')); ?></p>
				<?php endif; ?>
				<br>
			<?php endif; ?>
		</div>
		<div class='navigation-bar'>
			<div style="float: left;">
				<a href='/' title='Inicio'>Inicio</a>
				<a href='/destacados' id='forumEntry' title='Destacados'>Destacados</a>
				<a href='/tops' title='Tops'>Tops</a>
				<a href='/comunidades/' title='Comunidades'>Comunidades</a>
			</div>
			<div style="float: right;">
				<div class="search-bar">
					<input class='search-input' type='search' name='search' placeholder='Buscar...' autocomplete='off'>
					<button class="search-button">
						<img src="/src/media/search.png">
					</button>
					
				</div>
			</div>
		</div>
	</div>
	<?php $__env->startSection('body'); ?>
    <?php echo $__env->yieldSection(); ?>
    <div class="notification-bar"></div>
    <div class='footer'>
        <div class='social-network'>
            <a href='https://twitter.com/forohub' target='_blank' title='Twitter'><img src='/src/media/tw_logo.webp' alt='twitter_logo'></a>
            <a href='https://www.facebook.com/forohub/' target='_blank' title='Facebook'><img src='/src/media/fb_logo.webp' alt='facebook_logo'></a>
            <a href='https://www.instagram.com/_u/viboxx/' target='_blank' title='Instagram'><img src='/src/media/ig_logo.webp' alt='instagram_logo'></a>
        </div>
        <div class='info'>
        	|
        	<a href='/stats'>Estadísticas</a>
        	|
        	<a href='/stats'>Actualizaciones</a>
        	|
        	<a href='/thread/3'>FAQ</a>
        	|
        	<a href='/contact'>Contacto</a>
        	|
        </div>
    </div>  
</body>
</html><?php /**PATH C:\Users\david\Forohub\resources\views/layouts/desktop/main.blade.php ENDPATH**/ ?>