<?php if($reply_reports->isEmpty()): ?>
    <h2>No se han encontrado reportes de mensajes</h2>
<?php else: ?>
    <h2>Reportes de mensajes</h2>
    <div class="reply-reports-container">
    <?php $__currentLoopData = $reply_reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply_report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($reply_report->solved == 0): ?>
        <div class="reply-report unsolved" data-id="<?php echo e($reply_report->id); ?>">
        <?php else: ?>
        <div class="reply-report solved" data-id="<?php echo e($reply_report->id); ?>">
        <?php endif; ?>
            <div class="report-type">
                <label title="Mensaje">💬</label>
            </div>
            <div class="report-data">
                <label class="report-cause"><?php echo e($reply_report->report_type); ?></label>
                <label><b>Fecha: </b><label class="report-date"><?php echo e($reply_report->created_at); ?></label></label>
                <label><b>Enviado por: </b><a href="/u/<?php echo e(strtolower($reply_report->author->name)); ?>"><?php echo e($reply_report->author->name); ?></a></label>
                <?php if($reply_report->solved == 0): ?>
                <label><b>Estado: </b>Pendiente de revisión ❗</label>
                <?php else: ?>
                <label><b>Estado: </b>Resuelto ✔️</label>
                <?php endif; ?>
                <label><b>Fecha de vencimiento: </b><?php echo e(date('d/m/Y (H:i)', strtotime($reply_report->created_at->addDays(30)))); ?></label>
                <?php if($reply_report->description): ?>
                <label class="report-description"><b>Descripción: </b><?php echo e($reply_report->description); ?></label>
                <?php endif; ?>
            </div>
            <div class="report-actions">
                <a href="/c/<?php echo e($community->tag); ?>/t/<?php echo e($reply_report->thread_id); ?>?pagina=<?php echo e($reply_report->page); ?>#<?php echo e($reply_report->reply_id); ?>" target="_blank"><button>Ver Mensaje ↩️</button></a>
                <?php if($reply_report->solved == 0): ?>
                <button class="reply-solve">Marcar como resuelto ✔️</button>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?><?php /**PATH C:\Users\david\Forohub\resources\views/layouts/desktop/templates/community/reply_reports.blade.php ENDPATH**/ ?>