

<?php $__env->startSection('title', $community->title.' - Forohub'); ?>

<?php $__env->startSection('description', $meta_description); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" type="text/css" href="/css/B7o87L2YkZdnuQkqz68BKA35j2mc0OLjT86jSOrps19DHKjTHCVjMrjaQCpz7m6k.css">
    <link rel="stylesheet" type="text/css" href="/css/dYLviCaMKKoganQbQUa7lwhnlGund6PVLESCtn4jSJ00xXWCahDLUxHsMjyDFpHu.css">
    <link rel="stylesheet" type="text/css" href="/css/L02AaerYckTaqAgneODgPhYXNglw7NjScj7Wvu2SulxxotSZiCMHJpQ7fQKdIfU0.css">
    <link rel="stylesheet" type="text/css" href="/css/lMCdpjFSu5vMoCSIeycbdokrQqWyPZNLmvjARCwXWC4bkKQCg4BWhlpTQ1gqxMPI.css">
    <link rel="stylesheet" type="text/css" href="/css/MZZkS6zSSswEuYty9HW5AeUDm2Cwi2fd7lO7cZMmjcPf5QsZDNCJLaDf3E0o4QiY.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="/js/community.js"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('body'); ?>
<?php if(session('status')): ?>
    <script type="text/javascript">
        $(document).ready(function() {
           userVerifiedSuccess();
        });
    </script>
<?php endif; ?>
<?php if(session('warning')): ?>
  <div class="alert alert-warning">
    <?php echo e(session('warning')); ?>

  </div>
<?php endif; ?>
<?php if($community->background): ?>
    <script type="text/javascript">
        if (getCookie('DARK_THEME_CHECK') == 'TRUE') {
            $('html').css('backgroundImage', 'linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(<?php echo $community->background; ?>)');
        } else {
            $('html').css('backgroundImage', 'linear-gradient(rgba(255,255,255,0.5), rgba(255,255,255,0.5)), url(<?php echo $community->background; ?>');
        }
    </script>
    <style type="text/css">
        html {
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
            background-attachment: fixed;
        }
    </style>
<?php endif; ?>
<div class="index-panel">
    <div style="width: 10%"></div>
    <div class="threads-panel">
    <?php echo $__env->make('layouts.desktop.templates.community.community_configuration', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(isset($threads)): ?>
        <?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('layouts.desktop.templates.thread.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php if(empty($threads)): ?>
        <h3 class="required-auth">
            <a href="/crear/tema">Todavía no hay temas en esta comunidad.<br>Sé el primero en crear uno</a>
        </h3>
    <?php endif; ?>
</div>
    <div class="lateral-panel">
        <?php if($community->is_mod): ?> 
        <div class="lateral-cube">
            <div class="lateral-title">Panel de moderación</div>
            <div class="lateral-community-procedures">
                <a href="/c/<?php echo e($community->tag); ?>/reportes">
                    <button>Reportes 🚨</button>
                </a>
            </div>
        </div>
        <?php elseif($community->is_leader): ?>
        <div class="lateral-cube">
            <div class="lateral-title">Panel de moderación</div>
            <div class="lateral-community-procedures">
                <a href="/c/<?php echo e($community->tag); ?>/reportes">
                    <button>Reportes 🚨</button>
                </a>
                <a href="/c/<?php echo e($community->tag); ?>/afiliados/">
                    <button>Afiliados 👥</button>
                </a>
                <button class="community-configuration-trigger">Configuración ⚙️</button>
            </div>
        </div>
        <?php endif; ?>
        <?php echo $__env->make('layouts.desktop.templates.lateral.lateral_community', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php if(isset($threads)): ?>
    <?php if($threads->hasPages()): ?>
        <div style="text-align: center;">
            <div class="pageSelector">
              <?php echo $threads->links(); ?>

            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.desktop.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Forohub\resources\views/layouts/desktop/templates/community/community.blade.php ENDPATH**/ ?>