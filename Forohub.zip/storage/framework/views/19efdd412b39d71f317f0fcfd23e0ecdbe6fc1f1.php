<div class="thread" data-id="<?php echo e($thread->id); ?>">
    <div class="thread-data">
        <div class="thread-votes">
            <b class="thread-votes-data">
                <?php if(Auth::check()): ?>
                    <?php if($thread->user_vote_type == '1'): ?>
                        <span class="thread-vote upvote upvote-active" data-thread-id=<?php echo e($thread->id); ?>>▲</span>
                    <?php else: ?>
                        <span class="thread-vote upvote" data-thread-id=<?php echo e($thread->id); ?>>▲</span>
                    <?php endif; ?>
                        <span class="thread-vote-count"><?php echo e($thread->upvotes_count - $thread->downvotes_count); ?></span>
                    <?php if($thread->user_vote_type == '0'): ?>
                        <span class="thread-vote downvote downvote-active" data-thread-id=<?php echo e($thread->id); ?>>▼</span>
                    <?php else: ?>
                        <span class="thread-vote downvote" data-thread-id=<?php echo e($thread->id); ?>>▼</span>
                    <?php endif; ?>
                <?php else: ?>
                    <span class="required-auth thread-vote upvote" data-thread-id=<?php echo e($thread->id); ?>>▲</span>
                    <span class="thread-vote-count"><?php echo e($thread->upvotes_count - $thread->downvotes_count); ?></span>
                    <span class="required-auth thread-vote downvote" data-thread-id=<?php echo e($thread->id); ?>>▼</span>
                <?php endif; ?>
            </b>
        </div>
        <div class="thread-content">
            <span>
                <div class="thread-community">
                    <img class="thread-community-logo" src="<?php echo e($thread->communities->logo); ?>" alt="<?php echo e($thread->communities->name); ?>">
                    <b><a class="thread-community-name" href="/c/<?php echo e($thread->communities->tag); ?>"><?php echo e($thread->communities->tag); ?></a></b>
                </div>
                <?php if($thread->user_joined_community == 'true'): ?>
                    <button class="required-auth thread-community-joined">Cancelar suscripción</button>
                <?php else: ?>
                    <button class="required-auth thread-community-join">Suscribirse</button>
                <?php endif; ?>
            </span>
            <div class="thread-author">
                <span>Creado por <a href="/u/<?php echo e(strtolower($thread->author->name)); ?>"><?php echo e($thread->author->name); ?></a> · </span>
                <span>
                    <label class="thread-date"><?php echo e($thread->created_at); ?></label>
                </span>
            </div>
            <?php if($thread->important == true): ?>
            <label title="Tema serio">📑</label>
            <?php endif; ?>
            <?php if($thread->nsfw == true): ?>
            <label title="NSFW">🔞</label>
            <?php endif; ?>
            <?php if($thread->spoiler == true): ?>
            <label title="Spoiler">💥</label>
            <?php endif; ?>
            <h2 class="thread-title">
                <a href="/c/<?php echo e($thread->communities->tag); ?>/t/<?php echo e($thread->id); ?>"><?php echo e($thread->title); ?></a>
            </h2>
            <div class="thread-body"><?php if($thread->body != 'IS_POLL'): ?><?php echo $thread->body; ?><?php else: ?>
                <?php if($thread->poll_options): ?>
                <div class="poll-content">
                    <?php $__currentLoopData = $thread->poll_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="poll-option" data-id="<?php echo e($option->id); ?>">
                        <div class="option-bar">
                            <div class="option-data" style="width: <?php echo e($option->percentage); ?>%">
                                <b title="<?php echo e($option->name); ?>"><?php echo e($option->name); ?></b>
                                <label><?php echo e($option->percentage); ?>% (<?php echo e($option->votes_count); ?> votos)</label>
                            </div>
                        </div>
                        <div class="poll-option-vote">
                            <button class="required-auth poll-vote-button">Votar</button>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>    
                <?php endif; ?>
            <?php endif; ?>
            </div>
            <div class="thread-info">
                <a href="/c/<?php echo e($thread->communities->tag); ?>/t/<?php echo e($thread->id); ?>"><label style="text-shadow: none">💬</label> <?php echo e($thread->replies_count); ?> Mensajes</a>
                <span class="remarkable-text"><label>🔗</label> Compartir</span>
                <span class="required-auth remarkable-text report-thread"><label>❗</label> Reportar</span>
                <?php if($thread->closed == 0): ?>
                <span class="required-auth remarkable-text activate-reply"><label>↩️</label> Responder</span>
                <?php else: ?>
                <span class="remarkable-text"><label>🔒</label> Tema Cerrado</span>
                <?php endif; ?>
            </div>
            <?php if($thread->closed == 0): ?>
                <?php if(Auth::check()): ?>
                    <div class="thread-quick-reply">
                        <div>
                            <textarea class="thread-quick-reply-text" rows="4" maxlength="3000" placeholder="Deja un comentario..."></textarea>
                            <div class="character-counter">
                                <label>0</label>
                                <label>/3000</label>
                            </div>
                            <button class="thread-quick-reply-send" type="submit">Responder</button>
                            <button class="thread-quick-reply-cancel">Cancelar</button>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php /**PATH C:\Users\david\Forohub\resources\views/layouts/desktop/templates/thread/content.blade.php ENDPATH**/ ?>