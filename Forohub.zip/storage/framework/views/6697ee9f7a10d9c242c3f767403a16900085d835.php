

<?php $__env->startSection('title', 'Reportes · c/'.$community->tag.' - Forohub'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" type="text/css" href="/css/lsQ3ucw5ssUvul0bsFuTKR4vEPtw75deUZjctR9D1t3fRu2I1AaBRkhDCrpRFcHW.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="/js/community_reports.js"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('body'); ?>
<?php if(session('status')): ?>
    <script type="text/javascript">
        $(document).ready(function() {
           userVerifiedSuccess();
        });
    </script>
<?php endif; ?>
<?php if(session('warning')): ?>
  <div class="alert alert-warning">
    <?php echo e(session('warning')); ?>

  </div>
<?php endif; ?>
<?php if($community->background): ?>
    <script type="text/javascript">
        if (getCookie('DARK_THEME_CHECK') == 'TRUE') {
            $('html').css('backgroundImage', 'linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(<?php echo $community->background; ?>)');
        } else {
            $('html').css('backgroundImage', 'linear-gradient(rgba(255,255,255,0.5), rgba(255,255,255,0.5)), url(<?php echo $community->background; ?>');
        }
    </script>
    <style type="text/css">
        html {
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
            background-attachment: fixed;
        }
    </style>
<?php endif; ?>
    <div class="reports-container">
        <div class="reports-community">
            <div class="reports-community-logo">
                <img class="lateral-community-logo" src="<?php echo e($community->logo); ?>">
            </div>
            <div class="reports-community-data">
                <a href="/c/<?php echo e($community->tag); ?>"><?php echo e($community->title); ?></a>
                <label>c/<?php echo e($community->tag); ?></label>
            </div>
        </div>
        <h1 class="highlighted-title">Reportes</h1>
        <?php echo $__env->make('layouts.desktop.templates.community.thread_reports', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.desktop.templates.community.reply_reports', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.desktop.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\david\Forohub\resources\views/layouts/desktop/templates/community/reports.blade.php ENDPATH**/ ?>