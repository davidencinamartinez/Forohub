<div class="guide-selection">
	<a href="/{{ Request::segment(1) }}/{{ Request::segment(2) }}/{{ Request::segment(3) }}/" title="Todos">Todos</a>
	<a href="a" title="A">A</a>
	<a href="b" title="B">B</a>
	<a href="c" title="C">C</a>
	<a href="d" title="D">D</a>
	<a href="e" title="E">E</a>
	<a href="f" title="F">F</a>
	<a href="g" title="G">G</a>
	<a href="h" title="H">H</a>
	<a href="i" title="I">I</a>
	<a href="j" title="J">J</a>
	<a href="k" title="K">K</a>
	<a href="l" title="L">L</a>
	<a href="m" title="M">M</a>
	<a href="n" title="N">N</a>
	<a href="o" title="O">O</a>
	<a href="p" title="P">P</a>
	<a href="q" title="Q">Q</a>
	<a href="r" title="R">R</a>
	<a href="s" title="S">S</a>
	<a href="t" title="T">T</a>
	<a href="u" title="U">U</a>
	<a href="v" title="V">V</a>
	<a href="w" title="W">W</a>
	<a href="x" title="X">X</a>
	<a href="y" title="Y">Y</a>
	<a href="z" title="Z">Z</a>
	<a href="1" title="0-9">#</a>
</div>