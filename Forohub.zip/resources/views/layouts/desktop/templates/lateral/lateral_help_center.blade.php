<div class="lateral-cube">
	<div class="lateral-title">Centro de ayuda</div>
	<div class="help-center">
		<div class=" help-center-left">
			<a href="/comunidades/">Guía de comunidades</a>
			<a href="/temas/">Guía de temas</a>
			<a href="/usuarios/">Guía de usuarios</a>
			<a href="">Guía de tags</a>
		</div>
		<div class=" help-center-right">
			<a href="/privacy">Política de privacidad</a>
			<a href="">Política de contenido</a>
			<a href="">Política de moderación</a>
			<a href="">Contacto</a>
		</div>
	</div>
</div>